# NVG Cleaning Services - Next.js Website

## Deploy on Vercel
1. Upload this folder to GitHub.
2. Go to Vercel > Add New Project > Import the GitHub repo.
3. Deploy.
4. Add domain: nvgcleaningservices.co.uk.
5. Replace `G-XXXXXXXXXX` in `app/layout.jsx` with Google Analytics Measurement ID.
6. Replace `YOUR_FORM_ID` in `components/BookingForm.jsx` with Formspree ID or connect Resend.

## Included
- Next.js App Router
- Tailwind CSS
- Framer Motion reveal animations
- SEO metadata
- Sitemap and robots generation
- Local business schema
- Blog pages
- Gallery with real before/after images
- Mobile responsive layout
